#!/bin/bash
source /etc/profile
cp /apps/usr/nginx/nginx /etc/init.d/
cp /apps/usr/nginx/nginx.service /lib/systemd/system/
